﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using System.Reflection;
using System.Threading;
using System.Linq;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;

namespace StatusUpdateBox
{
    [TestFixture]
    public class TestClass
    {
        #region variable declaration
        public IWebDriver webDriver;
        public string projectPath;
        PageClass pageObj;
        ObjectRepoClass repoObj;
        #endregion

        [SetUp]
        public void StartReport()
        {   

            // chrone driver path
            var driverPath = System.IO.Directory.GetCurrentDirectory();
            //chrome options
            var options = new ChromeOptions();
            options.AddArguments("disable-infobars");
            options.AddArguments("no-sandbox");
            options.AddArguments("disable-single-click-autofill");
            options.AddArguments("no-first-run");
            options.AddArgument("ignore-certificate-errors");
            options.AddArguments("incognito");        
            // create chrome webdriver
            webDriver = new ChromeDriver(driverPath, options);
            // initialising Object repository members
            repoObj = new ObjectRepoClass();
            // initialising page class members
            pageObj = new PageClass(webDriver,repoObj);     
        }

        [Test]
        public void Verify_Status_Window_Opens_New_Popup_Window()
        {
            // Login to facebook account with valid login username and password
            CommonMethods.Login(webDriver);
            // Verify if status window opens with new pop up window on clicking.	
	        // "Verify if close button presents on pop up window and verify if window closes after clicking on it.
            pageObj.Verify_Status_Window_Opens_New_Popup_Window();

            //log out from account
            CommonMethods.LogOut(webDriver);
            Assert.Pass("Verified that status window opens with new pop up window on clicking. & Verified that close button presents on pop up window and verify if window closes after clicking on it.");
        
        }

        [Test]
        public void Verify_User_Can_Post_TextIn_Status_Update_box()
        {
            // Login to facebook account with valid login username and password
            CommonMethods.Login(webDriver);

            // Verify if user can post Text/photos/videos in status update.	
            pageObj.Verify_User_Can_Post_TextIn_Status_Update_And_Post();

            //log out from account
            CommonMethods.LogOut(webDriver);
            Assert.Pass("Verified that user can write something on status update box && Verified that user can able to see & click post button to update the status");
        }

        [TearDown]
        public void CloseAllBrowsers()
        {
            webDriver.Quit();
        }

    }
}
