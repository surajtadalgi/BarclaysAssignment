﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;
using System.Reflection;
using System.Threading;
using System.Linq;
using OpenQA.Selenium.Support.UI;

namespace StatusUpdateBox
{
    public static class CommonMethods
    {
        public static IWebDriver driver;

        public static string textToBePost = string.Format("{0} - Life is short. Work somewhere awsome.", Guid.NewGuid().ToString().Split('-').FirstOrDefault());
        
        public static void Login(IWebDriver  driver)
        {
            var repo = new ObjectRepoClass();
            driver.Navigate().GoToUrl("https://www.facebook.com/");
            driver.WaitForElement(repo.EmailField,10);
            driver.FindElement(repo.EmailField).ClearAndSendkeys("sonu.kale99");
            driver.FindElement(repo.PswdField).ClearAndSendkeys("sonu5010");
            driver.FindElement(repo.LogInButton).Click();
        }

        public static void LogOut(IWebDriver driver)
        {
            var repo = new ObjectRepoClass();
            
            try
            {
                driver.FindElement(repo.UserNavigationLable).Click();
                driver.WaitForElement(repo.LogOutLink);
                driver.FindElement(repo.LogOutLink).Click();
            }
            catch
            {
                driver.FindElement(By.ClassName("_3u15")).Click();
                driver.WaitForElement(repo.UserNavigationLable).Click();
                driver.WaitForElement(repo.LogOutLink);
                driver.FindElement(repo.LogOutLink).Click();
            }
            try
            {
                var alert = driver.SwitchTo().Alert();
                alert.Accept();
            }
            catch { }
        }

        public static void WaitOnPage(int seconds)
        {
            Thread.Sleep(TimeSpan.FromSeconds(seconds));
        }

    }

    #region Wrapper methods for selenium commands
    /// <summary>
    /// Extensions class for helper methods like WaitforElement, Findbutton, etc..
    /// </summary>
    public static class Extensions
    {
        #region Helper Methods
        public static void ClearAndSendkeys(this IWebElement webElement, string data)
        {
            webElement.Clear();
            webElement.SendKeys(data);
        }
        public static IWebElement WaitForElement(this IWebDriver driver, By locator, int maximumTimeSeconds = 8, int sleeptimeMiliseconds = 600)
        {
            //var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
            //return wait.Until(ExpectedConditions.ElementIsVisible((locator)));

            var endTime = DateTime.Now.AddSeconds(maximumTimeSeconds);
            IWebElement element = null;
            while (DateTime.Now <= endTime)
            {
                try
                {
                    element = driver.FindElement(locator);
                    break;
                }
                catch
                {
                    Thread.Sleep(sleeptimeMiliseconds);
                }
            }
            return element ?? driver.FindElement(locator);
        }
        public static void SelectByText(this IWebElement webElement, string text)
        {
            var select = new SelectElement(webElement);
            select.SelectByText(text);
        }
        public static void SelectByValue(this IWebElement webElement, string text)
        {
            var select = new SelectElement(webElement);
            select.SelectByValue(text);
        }
         public static IWebElement WaitForClickableElement(this IWebDriver driver, By locator, int seconds = 8)
        {
            var element = driver.FindElement(locator);
            try
            {
                var wait = new WebDriverWait(driver, new TimeSpan(0, 0, seconds));
                wait.Until(ExpectedConditions.ElementToBeClickable(locator));
            }
            catch
            {
                Assert.Fail(string.Format("Clickable element not found for locator: {locator}"));
            }
            return element;
        }

        #endregion
    }
    #endregion
}
