﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StatusUpdateBox
{
    class PageClass
    {
        IWebDriver webDriver;
        ObjectRepoClass repoObj;

        public PageClass(IWebDriver _webDriver,ObjectRepoClass _repoObj)
        {
            webDriver = _webDriver;
            repoObj = _repoObj;
        }

        internal void Verify_Status_Window_Opens_New_Popup_Window()
        {
            ClickOnHomePageAndStatusBoxandVerify();

            CommonMethods.WaitOnPage(6);
            // click on pop up close button to check whether it is closing or not
            webDriver.WaitForClickableElement(repoObj.StatusBoxPopupCloseButton, 20).Click();
        }

        private void ClickOnHomePageAndStatusBoxandVerify()
        {
            // click on home page link because sometimes it navigates to some other page after login
            webDriver.WaitForElement(repoObj.HomepageLink, 20).Click();

            // click on compose post to check whether it is opening new status pop up window or not
            webDriver.WaitForElement(repoObj.ComposePostLink, 20).Click();
        }


        internal void Verify_User_Can_Post_TextIn_Status_Update_And_Post()
        {
            ClickOnHomePageAndStatusBoxandVerify();

            // write something on status Update box 
            webDriver.WaitForElement(repoObj.StatusUpdateInputField, 20).ClearAndSendkeys(CommonMethods.textToBePost);
            
            // click on Post button to Update the status
            webDriver.FindElement(repoObj.PostButton).Click();

            // after posting the status..check that update post is visible or not
            Assert.True(webDriver.WaitForElement(repoObj.PostedBox) != null);
        }
    }
}
