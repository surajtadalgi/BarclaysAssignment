﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StatusUpdateBox
{
    class ObjectRepoClass
    {
        private By homePageLink = By.LinkText("Home");
        private By composePostLink = By.XPath(".//span[text()='Compose Post']");
        private By statusBoxPopupCloseButton = By.XPath(".//div[@aria-label='Dismiss']");
        private By statusUpdateInputField = By.XPath(".//*[@data-testid='status-attachment-mentions-input']");
        private By postButton = By.XPath(".//span[text()='Post']");
        private By postedBox = By.XPath(".//*[contains(@class,'userContentWrapper')]//p[contains(text(),'" + CommonMethods.textToBePost + "')]");
        private By emailField = By.Id("email");
        private By pswdField = By.Id("pass");
        private By logInButton = By.XPath(".//input[@value='Log In']");
        private By userNavigationLable = By.Id("userNavigationLabel");
        private By logOutLink = By.XPath(".//span[contains(text(),'Log out')]");

        public By HomepageLink
        { get { return homePageLink;} set { homePageLink = value; } }

        public By ComposePostLink
        { get { return composePostLink; } set { composePostLink = value; } }

        public By StatusBoxPopupCloseButton
        { get { return statusBoxPopupCloseButton; } set { statusBoxPopupCloseButton = value; } }

        public By StatusUpdateInputField
        { get { return statusUpdateInputField; } set { statusUpdateInputField = value; } }

        public By PostButton
        { get { return postButton; } set { postButton = value; } }

        public By PostedBox
        { get { return postedBox; } set { postedBox = value; } }

        public By EmailField
        { get { return emailField;} set { emailField = value; } }

        public By PswdField
        { get { return pswdField;} set { pswdField = value; } }

        public By LogInButton
        { get { return logInButton;} set { logInButton = value; } }

        public By UserNavigationLable
        { get { return userNavigationLable;} set { userNavigationLable = value; } }

         public By LogOutLink
        { get { return logOutLink;} set { logOutLink = value; } }

    }
}
